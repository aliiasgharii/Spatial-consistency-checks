// This block of code reads 3D objects in OBJ format from a folder and convert them to OFF format

#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <dirent.h>
#include <sys/types.h>
using namespace std;


vector<string> split(const string&, const string&);
void list_filepaths_filenames(const char*);

int main(int argc, char* argv[])
{
    list_filepaths_filenames("C:/Data/OBJ_OFF dataset/OBJ");
    //list_filenames("C:/dev/MyProg/Test/Dataset");
    std::ifstream myFile;
    std::ifstream myFile2;

    std::string line;
    std::string line2;
    int lines;

    myFile.open("C:/Data/OBJ_OFF dataset/dataset_filepaths.txt");
    myFile2.open("C:/Data/OBJ_OFF dataset/dataset_filenames.txt");
    for (lines = 1; std::getline(myFile, line), std::getline(myFile2, line2); lines++) {

        vector<vector<double>> vset;
        vector<vector<int>> fset;
        string line3;
        fstream h;
        h.open(line, ios::in);
        if (!h.is_open())
            cout << "File open error" << endl;
        int v_counter = 1;
        int f_counter = 1;
        while (!h.eof()) {
            getline(h, line3);//Get a line in the obj file as a string
            vector<string>parameters;
            string tailMark = " ";
            string ans = "";
            line3 = line3.append(tailMark);
            if (line3[0] != 'v' && line3[0] != 'f') {
                continue;
            }
            for (int i = 0; i < line3.length(); i++) {
                char ch = line3[i];
                if (ch != ' ') {
                    ans += ch;
                }
                else {
                    if (ans != "") {
                        parameters.push_back(ans); //Take out the elements in the string and divide them with spaces
                        ans = "";
                    }
                }
            }

            if (parameters[0] == "v") {   //If it is a vertex
                vector<double>Point;
                v_counter++;
                Point.push_back(atof(parameters[1].c_str()));
                Point.push_back(atof(parameters[2].c_str()));
                Point.push_back(atof(parameters[3].c_str()));
                vset.push_back(Point);
            }
            else if (parameters[0] == "f") {   //If it is a face, store the index of the vertex
                vector<int>vIndexSets;          //Collection of temporary storage points
                for (int i = 1; i < 4; i++) {
                    string x = parameters[i];
                    string ans = "";
                    for (int j = 0; j < x.length(); j++) {   //jump over'/'
                        char ch = x[j];
                        if (ch != '/')
                            ans += ch;
                        else
                            break;
                    }
                    vector<string >res = split(ans, "/");
                    int index = atof(res[0].c_str());
                    index--;//Because the vertex index starts from 1 in the obj file, and the vertex vector we store starts from 0, we need to subtract 1
                    vIndexSets.push_back(index);
                }
                fset.push_back(vIndexSets);
            }

        }
        h.close();
        int vert_number = vset.size();
        int face_number = fset.size();
        ofstream out("C:/Data/OBJ_OFF dataset/OFF converted/" + line2.substr(0) + ".off");
        out.precision(11);
        out << "OFF" << endl;
        out << vset.size() << " " << fset.size() << " 0" << endl;
        for (int j = 0; j < vset.size(); ++j) {
            out << (vset[j][0]) << " " << vset[j][1] << " " << vset[j][2] << endl;
        }
        for (int j = 0; j < fset.size(); ++j) {
            out << "3 " << (fset[j][0]) << " " << fset[j][1] << " " << fset[j][2] << endl;
        }
        out.close();
    }
}
// A function for listing the path and name for each object in a folder
void list_filepaths_filenames(const char* path) {
    struct dirent* entry;
    DIR* dir = opendir(path);

    if (dir == NULL) {
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        string ss = entry->d_name;
        std::string obj;
        obj = ss;
        const std::string ext(".obj");
        if (obj != ext &&
            obj.size() > ext.size() &&
            obj.substr(obj.size() - ext.size()) == ".obj")
        {
            // if so then strip them off
            obj = obj.substr(0, obj.size() - ext.size());
        }
        if (entry->d_type == DT_REG)
            if (ss[0] != '.') {

                //cout << "C:/dev/MyProg/Test/" << ss << endl;
                ofstream dataset_filepaths;
                dataset_filepaths.open("C:/Data/OBJ_OFF dataset/dataset_filepaths.txt", std::ios_base::app);
                dataset_filepaths << "C:/Data/OBJ_OFF dataset/OBJ/" << ss << endl;

                ofstream dataset_filenames;
                dataset_filenames.open("C:/Data/OBJ_OFF dataset/dataset_filenames.txt", std::ios_base::app);
                dataset_filenames << obj << endl;
            }
    }
    closedir(dir);
}
//Perform string cutting
vector<string> split(const string& str, const string& pattern)
{
    //const char* convert to char*
    char* strc = new char[strlen(str.c_str()) + 1];
    strcpy(strc, str.c_str());
    vector<string> resultVec;
    char* tmpStr = strtok(strc, pattern.c_str());
    while (tmpStr != NULL)
    {
        resultVec.push_back(string(tmpStr));
        tmpStr = strtok(NULL, pattern.c_str());
    }

    delete[] strc;

    return resultVec;
}
