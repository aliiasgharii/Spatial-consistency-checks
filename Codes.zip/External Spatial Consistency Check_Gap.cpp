// This block of code investigates the external spatial consistency of legal spaces (Checking gap).
// It takes OFF format as input. The OBJ file can also be read with some changes in code. 
// The legal spaces must be valid to go through this check. (internal spatial consistency checks can be used to identify errors)
// It investigates any gaps among 3D parcels in each level.
// The method provides the information of legal spaces surrounding gaps such as their names and GlobalID and also the geomtery of gapped spaces.
// The OBJ2OFF convertor can be used for converting OBJ files to OFF
// CopyRight (c) 2021 
// ---------------------------------------------------------------------
//#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Surface_mesh.h>
//#include <CGAL/Nef_polyhedron_3.h>
#include <iostream>
#include <sstream>
#include <fstream>
//#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_Surface_mesh.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <string>
#include <array> 
#include <CGAL/Cartesian.h>
#include <CGAL/Filtered_kernel.h>
#include <CGAL/Polyhedron_3.h>
#include <vector>
//#include <CGAL/IO/Polyhedron_iostream.h>
#include <CGAL/Polygon_mesh_processing/corefinement.h>
#include <CGAL/Polygon_mesh_processing/intersection.h>
#include <CGAL/Polygon_mesh_processing/self_intersections.h>
#include <CGAL/Polygon_mesh_processing/measure.h>
//#include <CGAL/Polygon_mesh_processing/repair_polygon_soup.h>
#include <CGAL/Polygon_mesh_processing/repair.h>
#include <CGAL/Polygon_mesh_processing/orient_polygon_soup.h>
#include <CGAL/Polygon_mesh_processing/polygon_soup_to_polygon_mesh.h>
#include <CGAL/Polygon_mesh_processing/connected_components.h>
#include <dirent.h>
#include <sys/types.h>
//#include <CGAL/IO/OBJ_reader.h>
#include <CGAL/IO/OFF_reader.h>
#include <CGAL/IO/print_wavefront.h>
#include <CGAL/boost/graph/Face_filtered_graph.h>

typedef double Real;
typedef CGAL::Cartesian < Real > Kernel0;
typedef CGAL::Filtered_kernel < Kernel0 > Kernel;
typedef CGAL::Polyhedron_3 < Kernel > Polyhedron;
typedef Kernel::Point_3 Point;
typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef CGAL::Surface_mesh<K::Point_3>  Mesh;
//typedef boost::graph_traits<Mesh>::face_descriptor face_descriptor;
//typedef boost::graph_traits<Mesh>::vertex_descriptor                 vertex_descriptor;
typedef boost::graph_traits<Mesh>::face_descriptor          face_descriptor;
typedef boost::graph_traits<Mesh>::faces_size_type          faces_size_type;
typedef Mesh::Property_map<face_descriptor, faces_size_type> FCCmap;
typedef CGAL::Face_filtered_graph<Mesh> Filtered_graph;
//typedef Polyhedron::Halfedge_handle    Halfedge_handle;
//typedef Polyhedron::Facet_handle       Facet_handle;
//typedef Polyhedron::Vertex_handle      Vertex_handle;
//typedef boost::graph_traits<Mesh>::halfedge_descriptor               halfedge_descriptor;
namespace params = CGAL::Polygon_mesh_processing::parameters;
//namespace NP = CGAL::parameters;
namespace PMP = CGAL::Polygon_mesh_processing;
using namespace std;

//A function for listng files names and paths
void list_filepaths_filenames(const char*);
void list_filepaths_filenames_OuterGeometry(const char*);
int main(int argc, char* argv[])
{

    list_filepaths_filenames("C:/dev/MyProg/Test/Dataset");
    list_filepaths_filenames_OuterGeometry("C:/dev/MyProg/Test/OuterGeometry");
    std::ifstream myFile0;
    std::ifstream myFile1;
    std::ifstream myFile2;
    //std::ifstream myFile2;
    std::string line3;
    std::string line2;
    std::string line1;
    std::string line0;
    int Number_of_OBJ;
    int lines = 0;
    myFile0.open("C:/dev/MyProg/Test/Union Result/dataset_filepaths.txt");
    myFile1.open("C:/dev/MyProg/Test/Union Result/dataset_filepaths_OuterGeometry.txt");
    //myFile2.open("C:/dev/MyProg/Test/Result/dataset_filenames.txt");
    int num_of_iteration = 0;
    string array[2000];
    string array1[2000];


    long int loop0 = 0;

    if (myFile0.is_open())
    {
        while (!myFile0.eof())
        {
            getline(myFile0, line0);
            array[loop0] = line0;
            //cout << array[loop] << endl;
            loop0++;
        }
        myFile0.close();
    }
    long int loop1 = 0;

    if (myFile1.is_open())
    {
        while (!myFile1.eof())
        {
            getline(myFile1, line1);
            array1[loop1] = line1;
            //cout << array[loop] << endl;
            loop1++;
        }
        myFile1.close();
    }
    int i;
    int j;
    int level;
    Number_of_OBJ = loop0 - 1;
    std::cout << "Number of objects in the dataset:" << Number_of_OBJ << endl;
    //____________________________________________________________________________________________________________________________________________________________________________________________//
    for (j = 0; j <= 5; j++) {
        Mesh Union;
        string level_num = to_string(j);
        // string arr[18] = { "00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17" };
         //string ar = arr[j];
     //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        for (i = 0; i < Number_of_OBJ; i++) {
            line2 = array[i];
            string str_level = line2.substr(32, 2);
            level = std::stoi(str_level);
            if (level == j) {
                cout << "The legal spaces on level " << level << " are being assessed." << endl;
                ifstream input3((argc > 1) ? argv[1] : line2);
                Mesh mesh3;
                if (input3 >> mesh3) {
                    std::cout << "The legal space " << array[i].substr(27, array[i].size() - 31) << " on level " << level << " is being assessed. " << '\n';
                    //CGAL::draw(mesh1);
                    Polyhedron Obj;
                    ifstream input4((argc > 1) ? argv[1] : line2);
                    input4 >> Obj;
                    std::ofstream output2("C:/dev/MyProg/Test/Dataset_OBJ/" + array[i].substr(27, array[i].size() - 31) + ".obj");
                    CGAL::print_polyhedron_wavefront(output2, Obj);
                }
                else if (!input3 || !(input3 >> mesh3) || mesh3.is_empty()) {
                    ifstream input3((argc > 1) ? argv[1] : line2);
                    //Converting non-2-manifold data to polygon soup and then polygon soup to Mesh and polyhedral surface---------------------------------------------
                    std::vector<K::Point_3> points;
                    std::vector<std::vector<std::size_t> > polygons;
                    if (!input3 || !CGAL::read_OFF(input3, points, polygons) || points.empty())
                    {
                        std::cerr << "Cannot open file " << array[i].substr(27, array[i].size() - 31) << std::endl;
                        return EXIT_FAILURE;
                    }
                    std::cout << "The legal space " << array[i].substr(27, array[i].size() - 31) << " on level " << level << " is being assessed. " << '\n';
                    CGAL::Polygon_mesh_processing::orient_polygon_soup(points, polygons);
                    CGAL::Polygon_mesh_processing::polygon_soup_to_polygon_mesh(points, polygons, mesh3);
                    //CGAL::draw(mesh1);
                }
                bool intersecting2 = PMP::does_self_intersect(mesh3,
                    PMP::parameters::vertex_point_map(get(CGAL::vertex_point, mesh3)));
                if (intersecting2) {

                    cout << " The 3D object " << array[i].substr(27, array[i].size() - 31) << " is self-intersected." << endl;

                }
                // cout << "we are drawing mesh!" << endl;
                // CGAL::draw(mesh3);
                Union += mesh3;
                // bool valid_union_geom = PMP::corefine_and_compute_union(mesh3, Union, Union, params::throw_on_self_intersection(true));
                //cout << "Now we are drawing union!" << endl;
                //CGAL::Polygon_mesh_processing::remove_self_intersections(Union);
                //CGAL::draw(Union);
            }


        } // for each object
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        if (!Union.is_empty()) {

            // Output the union result
            std::ofstream output("C:/dev/MyProg/Test/Union Result/Union_" + level_num + ".off");
            //std::ofstream output("C:/dev/MyProg/Test/Union Result/" + j + array[i].substr(27, array[i].size() - 31) + "_____" + array[j].substr(27, array[j].size() - 31) + ".off");
            output.precision(11);
            output << Union;
            Polyhedron P;
            ifstream input("C:/dev/MyProg/Test/Union Result/Union_" + level_num + ".off");
            input >> P;
            std::ofstream output1("C:/dev/MyProg/Test/Union Result/Union_" + level_num + ".obj");
            CGAL::print_polyhedron_wavefront(output1, P);
        }
        // Reading the outer geometries 
        line3 = array1[j];
        // Checking if the level of outer geometry and legal spaces is the same
        string str_level_outer = line3.substr(38, 2);
        int level_outer = std::stoi(str_level_outer);
        cout << "level_outer " << level_outer << endl;
        if (level_outer = level) {
            // If the level of outer geometry and legal spaces is the same then subtract the union of legal spaces from outer geomtery for each level
            Mesh Outer_geometry;
            std::cout << "The outer geometry is being assessed: " << array1[j].substr(33, array1[j].size() - 37) << '\n';
            ifstream input_outer((argc > 1) ? argv[1] : line3);
            input_outer >> Outer_geometry;
            Mesh  Gapped_spaces;
            // Gapped_spaces = Outer Geometry - Union of legal spaces (for each level)
            bool valid_union_geom = PMP::corefine_and_compute_difference(Outer_geometry, Union, Gapped_spaces, params::throw_on_self_intersection(true));
            if (!Gapped_spaces.is_empty()) {
                std::ofstream output_gap_spaces("C:/dev/MyProg/Test/Union Result/Gap_spaces_Level_" + level_num + ".off");
                output_gap_spaces.precision(11);
                output_gap_spaces << Gapped_spaces;
            }
            if (!Gapped_spaces.is_empty()) {
                Polyhedron G;
                ifstream input("C:/dev/MyProg/Test/Union Result/Gap_spaces_Level_" + level_num + ".off");
                input >> G;
                std::ofstream output_gap_spaces1("C:/dev/MyProg/Test/Union Result/Gap_spaces_Level_" + level_num + ".obj");
                CGAL::print_polyhedron_wavefront(output_gap_spaces1, G);
            }
            //CGAL::Polygon_mesh_processing::split_connected_components(Gapped_spaces, cc_meshes);
            // Splitting the gapped_spaces into seperate geometries
            FCCmap fccmap = Gapped_spaces.add_property_map<face_descriptor, faces_size_type>
                ("f:CC").first;
            faces_size_type num = PMP::connected_components(Gapped_spaces, fccmap);
            std::vector<Mesh> splitted_meshes(num);
            for (int k = 0; k < num; ++k)
            {
                Filtered_graph ffg(Gapped_spaces, k, fccmap);
                CGAL::copy_face_graph(ffg, splitted_meshes[k]);
                CGAL::draw(splitted_meshes[k]);
                string mesh_num = to_string(k);

                if (!splitted_meshes[k].is_empty()) {

                    //cout << "C:/dev/MyProg/Test/Union Result/splitted_meshes_" << k << "_level" << ar << ".off" << endl;
                    std::ofstream output_splitted_meshes("C:/dev/MyProg/Test/Union Result/splitted_meshes_Level_" + level_num + "_" + mesh_num + ".off");
                    output_splitted_meshes.precision(11);
                    output_splitted_meshes << splitted_meshes[k];
                }

                for (i = 0; i < Number_of_OBJ; i++) {
                    line2 = array[i];
                    string str_level = line2.substr(32, 2);
                    level = std::stoi(str_level);

                    ifstream input3((argc > 1) ? argv[1] : line2);
                    Mesh legal_spaces;
                    if (input3 >> legal_spaces) {
                        std::cout << "Touch check for 2-manifold object: " << array[i].substr(27, array[i].size() - 31) << " on level " << level << '\n';
                    }
                    else if (!input3 || !(input3 >> legal_spaces) || legal_spaces.is_empty()) {
                        ifstream input3((argc > 1) ? argv[1] : line2);
                        //Converting non-2-manifold data to polygon soup and then polygon soup to Mesh and polyhedral surface---------------------------------------------
                        std::vector<K::Point_3> points;
                        std::vector<std::vector<std::size_t> > polygons;
                        if (!input3 || !CGAL::read_OFF(input3, points, polygons) || points.empty())
                        {
                            std::cerr << "Cannot open file " << array[i].substr(27, array[i].size() - 31) << std::endl;
                            return EXIT_FAILURE;
                        }
                        std::cout << "Touch check for non-2-manifold object: " << array[i].substr(27, array[i].size() - 31) << " on level " << level << '\n';
                        CGAL::Polygon_mesh_processing::orient_polygon_soup(points, polygons);
                        CGAL::Polygon_mesh_processing::polygon_soup_to_polygon_mesh(points, polygons, legal_spaces);
                    }
                    bool valid_intersection = PMP::do_intersect(splitted_meshes[k], legal_spaces, params::do_overlap_test_of_bounded_sides(true), params::do_overlap_test_of_bounded_sides(true));

                    if (valid_intersection) {
                        Mesh out;
                        bool valid_intersection_geom = PMP::corefine_and_compute_intersection(splitted_meshes[k], legal_spaces, out, params::throw_on_self_intersection(true));
                        if (out.is_empty()) {
                            ofstream file;
                            file.open("C:/dev/MyProg/Test/Union Result/Gap report.txt", std::ios_base::app);
                            if (!file)
                            {
                                std::cout << "Error in creating file!!!";

                            }
                            file
                                << "The legal space adjoining the gap space: " << array[i].substr(27, array[i].size() - 31) << " ##### " << "splitted_meshes_Level_" + level_num + "_" + mesh_num << "\n"

                                ;
                        }
                    }



                }
                ofstream file;
                file.open("C:/dev/MyProg/Test/Union Result/Gap report.txt", std::ios_base::app);
                if (!file)
                {
                    std::cout << "Error in creating file!!!";

                }
                file
                    << " ----------------------------------------------------------------------------------------------------------------------------- " << "\n";

            }

        }

    } // For level
    //____________________________________________________________________________________________________________________________________________________________________________________________//


} // int main

// A function for listing the path and name for each object in a folder
void list_filepaths_filenames(const char* path) {
    struct dirent* entry;
    DIR* dir = opendir(path);
    if (dir == NULL) {
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        string ss = entry->d_name;
        std::string obj;
        obj = ss;
        const std::string ext(".obj");
        if (obj != ext &&
            obj.size() > ext.size() &&
            obj.substr(obj.size() - ext.size()) == ".obj")
        {
            // if so then strip them off
            obj = obj.substr(0, obj.size() - ext.size());
        }
        if (entry->d_type == DT_REG)
            if (ss[0] != '.') {

                //cout << "C:/dev/MyProg/Test/" << ss << endl;
                ofstream dataset_filepaths;
                dataset_filepaths.open("C:/dev/MyProg/Test/Union Result/dataset_filepaths.txt", std::ios_base::app);
                dataset_filepaths << "C:/dev/MyProg/Test/Dataset/" << ss << endl;

                ofstream dataset_filenames;
                dataset_filenames.open("C:/dev/MyProg/Test/Union Result/dataset_filenames.txt", std::ios_base::app);
                dataset_filenames << obj << endl;
            }
    }
    closedir(dir);
}
void list_filepaths_filenames_OuterGeometry(const char* path) {
    struct dirent* entry;
    DIR* dir = opendir(path);
    if (dir == NULL) {
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        string ss = entry->d_name;
        std::string obj;
        obj = ss;
        const std::string ext(".obj");
        if (obj != ext &&
            obj.size() > ext.size() &&
            obj.substr(obj.size() - ext.size()) == ".obj")
        {
            // if so then strip them off
            obj = obj.substr(0, obj.size() - ext.size());
        }
        if (entry->d_type == DT_REG)
            if (ss[0] != '.') {

                //cout << "C:/dev/MyProg/Test/" << ss << endl;
                ofstream dataset_filepaths;
                dataset_filepaths.open("C:/dev/MyProg/Test/Union Result/dataset_filepaths_OuterGeometry.txt", std::ios_base::app);
                dataset_filepaths << "C:/dev/MyProg/Test/OuterGeometry/" << ss << endl;

                ofstream dataset_filenames;
                dataset_filenames.open("C:/dev/MyProg/Test/Union Result/dataset_filenames_OuterGeometry.txt", std::ios_base::app);
                dataset_filenames << obj << endl;
            }
    }
    closedir(dir);
}
