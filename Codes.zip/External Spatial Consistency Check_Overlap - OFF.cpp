// This block of code investigates the external spatial consistency of legal spaces.
// It takes OFF format as input. The OBJ file can also be read with some changes in code. 
// The legal spaces must be valid to go through this check. (internal spatial consistency checks can be used to identify errors)
// It investigates any overlaps among 3D parcels and also other topological relationships such as touch and disjoint.
// The method provides the information of overlapping legal spaces such as their names and GlobalID and also the geomtery of overlapped spaces.
// The OBJ2OFF convertor can be used for converting OBJ files to OFF
// CopyRight (c) 2021 
// ---------------------------------------------------------------------
//#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Surface_mesh.h>
//#include <CGAL/Nef_polyhedron_3.h>
#include <iostream>
#include <sstream>
#include <fstream>
//#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_Surface_mesh.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <string>
#include <array> 
#include <CGAL/Cartesian.h>
#include <CGAL/Filtered_kernel.h>
//#include <CGAL/Polyhedron_3.h>
#include <vector>
//#include <CGAL/IO/Polyhedron_iostream.h>
#include <CGAL/Polygon_mesh_processing/corefinement.h>
#include <CGAL/Polygon_mesh_processing/intersection.h>
#include <CGAL/Polygon_mesh_processing/self_intersections.h>
#include <CGAL/Polygon_mesh_processing/measure.h>
//#include <CGAL/Polygon_mesh_processing/repair_polygon_soup.h>
#include <CGAL/Polygon_mesh_processing/repair.h>
#include <CGAL/Polygon_mesh_processing/orient_polygon_soup.h>
#include <CGAL/Polygon_mesh_processing/polygon_soup_to_polygon_mesh.h>
#include <dirent.h>
#include <sys/types.h>
//#include <CGAL/IO/OBJ_reader.h>
#include <CGAL/IO/OFF_reader.h>
//#include <CGAL/IO/print_wavefront.h>


typedef double Real;
typedef CGAL::Cartesian < Real > Kernel0;
typedef CGAL::Filtered_kernel < Kernel0 > Kernel;
//typedef CGAL::Polyhedron_3 < Kernel > Polyhedron;
typedef Kernel::Point_3 Point;
typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef CGAL::Surface_mesh<K::Point_3>  Mesh;
//typedef boost::graph_traits<Mesh>::face_descriptor face_descriptor;
//typedef boost::graph_traits<Mesh>::vertex_descriptor                 vertex_descriptor;
//typedef Polyhedron::Halfedge_handle    Halfedge_handle;
//typedef Polyhedron::Facet_handle       Facet_handle;
//typedef Polyhedron::Vertex_handle      Vertex_handle;
//typedef boost::graph_traits<Mesh>::halfedge_descriptor               halfedge_descriptor;
namespace params = CGAL::Polygon_mesh_processing::parameters;
//namespace NP = CGAL::parameters;
namespace PMP = CGAL::Polygon_mesh_processing;
using namespace std;

//A function for listng files names and paths
void list_filepaths_filenames(const char*);

int main(int argc, char* argv[])
{
    list_filepaths_filenames("C:/dev/MyProg/Test/Dataset");

    std::ifstream myFile;
    //std::ifstream myFile2;
    std::string line0;
    std::string line1;
    std::string line2;
    int Number_of_OBJ;
    int lines = 0;
    myFile.open("C:/dev/MyProg/Test/Intersection Result/dataset_filepaths.txt");
    //myFile2.open("C:/dev/MyProg/Test/Result/dataset_filenames.txt");

    /*while (std::getline(myFile, line0)) {
        Number_of_OBJ++;
    }*/

    //std::vector<std::string> array{ };

    int num_of_iteration = 0;
    string array[2000];
    //string* array = NULL;
   // array = new string[Number_of_OBJ];
    long int loop = 0;
    if (myFile.is_open())
    {
        while (!myFile.eof())
        {
            getline(myFile, line1);
            array[loop] = line1;
            //cout << array[loop] << endl;
            loop++;
        }
        myFile.close();
    }
    Number_of_OBJ = loop - 1;
    std::cout << "Number of objects in the dataset:" << Number_of_OBJ << endl;

    //for (int i = 0; i < Number_of_OBJ; i++) {
       ////std::cout << "The paths: " << '\n'
           //// << array[i] << endl;
        //cout << "array size" << array[i].size() << endl;
   // }

    for (int i = 0; i < Number_of_OBJ; i++) {

        line1 = array[i];

        ifstream input1((argc > 1) ? argv[1] : line1);
        // Polyhedron mesh;
        Mesh mesh1;

        if (input1 >> mesh1) {
            std::cout << "The 2-manifold object is being assessed: " << array[i].substr(27, array[i].size() - 31) << '\n';
            //CGAL::draw(mesh1);
        }
        else if (!input1 || !(input1 >> mesh1) || mesh1.is_empty()) {
            ifstream input1((argc > 1) ? argv[1] : line1);
            //Converting non-2-manifold data to polygon soup and then polygon soup to Mesh and polyhedral surface---------------------------------------------
            std::vector<K::Point_3> points;
            std::vector<std::vector<std::size_t> > polygons;

            if (!input1 || !CGAL::read_OFF(input1, points, polygons) || points.empty())
            {
                std::cerr << "Cannot open file " << array[i].substr(27, array[i].size() - 31) << std::endl;
                return EXIT_FAILURE;
            }
            std::cout << "The non-2-manifold object is being assessed: " << array[i].substr(27, array[i].size() - 31) << '\n';

            CGAL::Polygon_mesh_processing::orient_polygon_soup(points, polygons);
            CGAL::Polygon_mesh_processing::polygon_soup_to_polygon_mesh(points, polygons, mesh1);
            //CGAL::draw(mesh1);
        }
        bool intersecting = PMP::does_self_intersect(mesh1,
            PMP::parameters::vertex_point_map(get(CGAL::vertex_point, mesh1)));
        if (intersecting) {

            cout << " The 3D object " << array[i].substr(27, array[i].size() - 31) << " is self-intersected." << endl;

            //cout << " Self-intersection status:" << array[i].substr(27, array[i].size() - 31)  << endl << (intersecting ? " The 3D object is self-intersected." : "The 3D object is not self-intersected.") << endl;
        }

        for (int j = i + 1; j < Number_of_OBJ; j++) {
            line2 = array[j];
            ifstream input2((argc > 1) ? argv[1] : line2);
            Mesh mesh2;
            if (input2 >> mesh2) {
                std::cout << "The 2-manifold object is being assessed: " << array[j].substr(27, array[j].size() - 31) << '\n';
                //CGAL::draw(mesh2);
            }
            else if (!input2 || !(input2 >> mesh2) || mesh2.is_empty()) {
                ifstream input2((argc > 1) ? argv[1] : line2);
                std::vector<K::Point_3> points;
                std::vector<std::vector<std::size_t> > polygons;

                if (!input2 || !CGAL::read_OFF(input2, points, polygons) || points.empty())
                {
                    std::cerr << "Cannot open file " << array[j].substr(27, array[j].size() - 31) << std::endl;
                    return EXIT_FAILURE;
                }
                std::cout << "The non-2-manifold object is being assessed: " << array[j].substr(27, array[j].size() - 31) << '\n';
                CGAL::Polygon_mesh_processing::orient_polygon_soup(points, polygons);
                CGAL::Polygon_mesh_processing::polygon_soup_to_polygon_mesh(points, polygons, mesh2);
                //CGAL::draw(mesh1);
                  //CGAL::draw(mesh2);
            }
            //cout << "The objects assessed:::::::  " << array[i].substr(27) << "     " << array[j].substr(27) << endl;
            bool intersecting = PMP::does_self_intersect(mesh2,
                PMP::parameters::vertex_point_map(get(CGAL::vertex_point, mesh2)));
            if (intersecting) {

                cout << " The 3D object " << array[j].substr(27, array[j].size() - 31) << " is self-intersected." << endl;

                //cout << " Self-intersection status:" << array[j].substr(27, array[j].size() - 31) << endl << (intersecting ? " The 3D object is self-intersected." : "The 3D object is not self-intersected.") << endl;

            }
            CGAL::Polygon_mesh_processing::remove_self_intersections(mesh1);
            CGAL::Polygon_mesh_processing::remove_self_intersections(mesh2);

            bool valid_intersection = PMP::do_intersect(mesh1, mesh2, params::do_overlap_test_of_bounded_sides(true), params::do_overlap_test_of_bounded_sides(true));


            if (valid_intersection)
            {

                Mesh out;
                bool valid_intersection_geom = PMP::corefine_and_compute_intersection(mesh1, mesh2, out, params::throw_on_self_intersection(true));

                if (!out.is_empty()) {

                    std::cout << "The overlapped legal spaces: " << array[i].substr(27, array[i].size() - 31) << " ##### " << array[j].substr(27, array[j].size() - 31) << "\n" << "\n";
                    // Output the intersection result
                    ofstream file;
                    file.open("C:/dev/MyProg/Test/Intersection Result/Overlapping report.txt", std::ios_base::app);
                    if (!file)
                    {
                        std::cout << "Error in creating file!!!";

                    }
                    file
                        << "The overlapped legal spaces: " << array[i].substr(27, array[i].size() - 31) << " ##### " << array[j].substr(27, array[j].size() - 31) << "\n"
                        << " ----------------------------------------------------------------------------------------------------------------------------- " << "\n"
                        ;
                    //Extracting the geomtery of spaces overlapped 
                    std::ofstream output("C:/dev/MyProg/Test/Intersection Result/" + array[i].substr(27, array[i].size() - 31) + "_____" + array[j].substr(27, array[j].size() - 31) + ".off");
                    output.precision(11);
                    output << out;
                    //output.close();
                     //CGAL::print_polyhedron_wavefront(output, mesh1);
                     //CGAL::draw(out);*/
                    //CGAL::draw(out);
                }
                else if (out.is_empty()) {

                    ofstream file2;
                    file2.open("C:/dev/MyProg/Test/Intersection Result/Touching report.txt", std::ios_base::app);
                    if (!file2)
                    {
                        std::cout << "Error in creating file!!!";

                    }
                    file2
                        << "The legal spaces touched each other:  " << array[i].substr(27, array[i].size() - 31) << " ##### " << array[j].substr(27, array[j].size() - 31) << "\n"
                        << " ----------------------------------------------------------------------------------------------------------------------------- " << "\n"
                        ;

                }
            }
        }
        num_of_iteration++;
        std::cout << "Number of iteration: " << num_of_iteration << endl;
        std::cout << "-----------------------------------------------------------------------------------------------------------------------" << "\n";
    }
    // delete[] array;
}
// A function for listing the path and name for each object in a folder
void list_filepaths_filenames(const char* path) {
    struct dirent* entry;
    DIR* dir = opendir(path);
    if (dir == NULL) {
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        string ss = entry->d_name;
        std::string obj;
        obj = ss;
        const std::string ext(".obj");
        if (obj != ext &&
            obj.size() > ext.size() &&
            obj.substr(obj.size() - ext.size()) == ".obj")
        {
            // if so then strip them off
            obj = obj.substr(0, obj.size() - ext.size());
        }
        if (entry->d_type == DT_REG)
            if (ss[0] != '.') {

                //cout << "C:/dev/MyProg/Test/" << ss << endl;
                ofstream dataset_filepaths;
                dataset_filepaths.open("C:/dev/MyProg/Test/Intersection Result/dataset_filepaths.txt", std::ios_base::app);
                dataset_filepaths << "C:/dev/MyProg/Test/Dataset/" << ss << endl;

                ofstream dataset_filenames;
                dataset_filenames.open("C:/dev/MyProg/Test/Intersection Result/dataset_filenames.txt", std::ios_base::app);
                dataset_filenames << obj << endl;
            }
    }
    closedir(dir);
}
